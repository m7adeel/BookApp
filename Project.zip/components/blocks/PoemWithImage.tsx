import { View, Text } from 'react-native'
import React from 'react'

export default function PoemWithImage() {
  return (
    <View>
      <Text>PoemWithImage</Text>
    </View>
  )
}